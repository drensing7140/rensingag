import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Customers — the farmers/growers that hire us
export const customers = sqliteTable("customers", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  phone: text("phone"),
  email: text("email"),
  address: text("address"),
  notes: text("notes"),
  createdAt: integer("created_at").notNull(),
});

export const insertCustomerSchema = createInsertSchema(customers).omit({
  id: true,
  createdAt: true,
});

export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Customer = typeof customers.$inferSelect;

// Fields — owned by a customer
export const fields = sqliteTable("fields", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  customerId: integer("customer_id").notNull(),
  name: text("name").notNull(), // e.g. "North 40", "Smith Bottom"
  location: text("location"), // street address or description
  latitude: real("latitude"),
  longitude: real("longitude"),
  acres: real("acres"),
  cropType: text("crop_type"), // corn, soybeans, wheat, etc.
  product: text("product"), // chemical/fungicide to apply
  rate: text("rate"), // application rate e.g. "6 oz/acre"
  notes: text("notes"),
  status: text("status").notNull().default("pending"), // pending, scheduled, sprayed, skipped
  scheduledDate: text("scheduled_date"), // ISO date string
  sprayedDate: text("sprayed_date"), // ISO date string
  createdAt: integer("created_at").notNull(),
});

export const insertFieldSchema = createInsertSchema(fields, {
  customerId: z.number().int().positive(),
  acres: z.coerce.number().nonnegative().optional().nullable(),
  latitude: z.coerce.number().optional().nullable(),
  longitude: z.coerce.number().optional().nullable(),
}).omit({
  id: true,
  createdAt: true,
});

export type InsertField = z.infer<typeof insertFieldSchema>;
export type Field = typeof fields.$inferSelect;

// Convenience joined type used by the frontend
export type FieldWithCustomer = Field & { customerName: string };

// Customer submissions — public intake form. Stored separately so employees
// can review before approving them into customers/fields.
export const submissions = sqliteTable("submissions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  // Contact
  customerName: text("customer_name").notNull(),
  phone: text("phone"),
  email: text("email"),
  address: text("address"),
  customerNotes: text("customer_notes"),
  // Field details (JSON array of FieldRequest)
  fieldsJson: text("fields_json").notNull(),
  status: text("status").notNull().default("new"), // new, approved, dismissed
  createdAt: integer("created_at").notNull(),
});

export const fieldRequestSchema = z.object({
  name: z.string().min(1, "Field name is required"),
  location: z.string().optional().nullable(),
  latitude: z.coerce.number().optional().nullable(),
  longitude: z.coerce.number().optional().nullable(),
  acres: z.coerce.number().nonnegative().optional().nullable(),
  cropType: z.string().optional().nullable(),
  product: z.string().optional().nullable(),
  rate: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});
export type FieldRequest = z.infer<typeof fieldRequestSchema>;

export const insertSubmissionSchema = z.object({
  customerName: z.string().min(1, "Your name or farm name is required"),
  phone: z.string().optional().nullable(),
  email: z.string().email("Enter a valid email").optional().nullable().or(z.literal("")),
  address: z.string().optional().nullable(),
  customerNotes: z.string().optional().nullable(),
  fields: z.array(fieldRequestSchema).min(1, "Add at least one field"),
});
export type InsertSubmission = z.infer<typeof insertSubmissionSchema>;
export type Submission = typeof submissions.$inferSelect;
export type SubmissionWithFields = Submission & { fields: FieldRequest[] };
