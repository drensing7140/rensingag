import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Phone, Mail, MapPin, CheckCircle2, X, Navigation, Inbox as InboxIcon, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { SubmissionWithFields } from "@shared/schema";
import { fmtAcres, fmtDate } from "@/lib/format";
import { cn } from "@/lib/utils";

const STATUS_BADGE: Record<string, string> = {
  new: "bg-[hsl(43_74%_88%)] text-[hsl(43_60%_25%)] border-[hsl(43_50%_70%)] dark:bg-[hsl(43_30%_22%)] dark:text-[hsl(43_70%_70%)] dark:border-[hsl(43_30%_35%)]",
  approved: "bg-[hsl(103_40%_88%)] text-[hsl(103_56%_25%)] border-[hsl(103_30%_70%)] dark:bg-[hsl(103_25%_20%)] dark:text-[hsl(97_45%_70%)] dark:border-[hsl(103_25%_35%)]",
  dismissed: "bg-muted text-muted-foreground border-border",
};
const STATUS_LABEL: Record<string, string> = {
  new: "New",
  approved: "Approved",
  dismissed: "Dismissed",
};

function mapsHref(lat?: number | null, lng?: number | null, loc?: string | null) {
  if (lat != null && lng != null) return `https://maps.google.com/?q=${lat},${lng}`;
  if (loc) return `https://maps.google.com/?q=${encodeURIComponent(loc)}`;
  return null;
}

export default function Inbox() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { data, isLoading } = useQuery<SubmissionWithFields[]>({ queryKey: ["/api/submissions"] });
  const [filter, setFilter] = useState("new");
  const [viewing, setViewing] = useState<SubmissionWithFields | null>(null);

  const approve = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("POST", `/api/submissions/${id}/approve`, {});
      return res.json();
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["/api/submissions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/customers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/fields"] });
      toast({ title: "Request approved", description: "Added to Customers and Fields." });
      setViewing(null);
      navigate(`/employee/customers/${result.customerId}`);
    },
    onError: () => toast({ title: "Could not approve request", variant: "destructive" }),
  });

  const dismiss = useMutation({
    mutationFn: async (id: number) => apiRequest("POST", `/api/submissions/${id}/dismiss`, {}),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/submissions"] });
      toast({ title: "Request dismissed" });
      setViewing(null);
    },
  });

  const del = useMutation({
    mutationFn: async (id: number) => apiRequest("DELETE", `/api/submissions/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/submissions"] });
      toast({ title: "Removed" });
      setViewing(null);
    },
  });

  const items = (data ?? []).filter((s) => filter === "all" || s.status === filter);
  const newCount = (data ?? []).filter((s) => s.status === "new").length;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-xl font-semibold tracking-tight">Inbox</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Customer-submitted spray requests. Review each one and approve it to create the customer and fields.
        </p>
      </header>

      <Tabs value={filter} onValueChange={setFilter}>
        <TabsList data-testid="tabs-inbox">
          <TabsTrigger value="new" data-testid="tab-new">
            New {newCount > 0 && <span className="ml-1.5 rounded-full bg-primary px-1.5 py-0.5 text-xs text-primary-foreground">{newCount}</span>}
          </TabsTrigger>
          <TabsTrigger value="approved" data-testid="tab-approved">Approved</TabsTrigger>
          <TabsTrigger value="dismissed" data-testid="tab-dismissed">Dismissed</TabsTrigger>
          <TabsTrigger value="all" data-testid="tab-all">All</TabsTrigger>
        </TabsList>
      </Tabs>

      {isLoading ? (
        <div className="space-y-2">
          {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-md" />)}
        </div>
      ) : items.length === 0 ? (
        <Card className="border-card-border">
          <CardContent className="flex flex-col items-center gap-3 px-6 py-16 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-accent text-accent-foreground">
              <InboxIcon className="h-6 w-6" />
            </div>
            <div className="text-sm text-muted-foreground" data-testid="empty-inbox">
              {filter === "new"
                ? "No new requests right now."
                : `No ${filter} requests.`}
            </div>
            <div className="text-xs text-muted-foreground">
              Share the customer request link to start collecting requests.
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {items.map((s) => {
            const pinCount = s.fields.filter((f) => f.latitude != null && f.longitude != null).length;
            const totalAcres = s.fields.reduce((sum, f) => sum + (f.acres ?? 0), 0);
            return (
              <Card key={s.id} data-testid={`card-submission-${s.id}`} className="border-card-border">
                <CardContent className="p-5">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                        <h3 className="text-base font-semibold leading-tight" data-testid={`text-name-${s.id}`}>
                          {s.customerName}
                        </h3>
                        <span className={cn("rounded-full border px-2 py-0.5 text-xs font-medium", STATUS_BADGE[s.status])}>
                          {STATUS_LABEL[s.status]}
                        </span>
                      </div>
                      <div className="mt-1 text-xs text-muted-foreground">
                        Received {fmtDate(s.createdAt)} · {s.fields.length} field{s.fields.length === 1 ? "" : "s"} · {fmtAcres(totalAcres || null)} · {pinCount} pin{pinCount === 1 ? "" : "s"}
                      </div>
                      <div className="mt-2 flex flex-wrap gap-3 text-xs text-muted-foreground">
                        {s.phone && <span className="inline-flex items-center gap-1"><Phone className="h-3 w-3" />{s.phone}</span>}
                        {s.email && <span className="inline-flex items-center gap-1"><Mail className="h-3 w-3" />{s.email}</span>}
                        {s.address && <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3" />{s.address}</span>}
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setViewing(s)}
                        data-testid={`button-review-${s.id}`}
                      >
                        Review
                      </Button>
                      {s.status === "new" && (
                        <Button
                          size="sm"
                          onClick={() => approve.mutate(s.id)}
                          disabled={approve.isPending}
                          data-testid={`button-approve-${s.id}`}
                        >
                          <CheckCircle2 className="h-4 w-4 mr-1" /> Approve
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Detail dialog */}
      <Dialog open={viewing !== null} onOpenChange={(o) => !o && setViewing(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{viewing?.customerName}</DialogTitle>
          </DialogHeader>
          {viewing && (
            <div className="space-y-4">
              <Card className="border-card-border">
                <CardHeader className="pb-2"><CardTitle className="text-sm">Contact</CardTitle></CardHeader>
                <CardContent className="space-y-1.5 pb-4 text-sm">
                  {viewing.phone && <div className="flex items-center gap-2"><Phone className="h-3.5 w-3.5 text-muted-foreground" /><a href={`tel:${viewing.phone}`} className="hover:text-primary">{viewing.phone}</a></div>}
                  {viewing.email && <div className="flex items-center gap-2"><Mail className="h-3.5 w-3.5 text-muted-foreground" /><a href={`mailto:${viewing.email}`} className="hover:text-primary">{viewing.email}</a></div>}
                  {viewing.address && <div className="flex items-start gap-2"><MapPin className="h-3.5 w-3.5 mt-0.5 text-muted-foreground" /><span>{viewing.address}</span></div>}
                  {viewing.customerNotes && <div className="mt-2 rounded-md bg-accent/40 p-3">{viewing.customerNotes}</div>}
                </CardContent>
              </Card>

              <div>
                <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Fields ({viewing.fields.length})
                </h3>
                <div className="space-y-2">
                  {viewing.fields.map((f, i) => {
                    const href = mapsHref(f.latitude, f.longitude, f.location);
                    return (
                      <Card key={i} className="border-card-border">
                        <CardContent className="space-y-2 p-4 text-sm">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <div className="font-semibold">{f.name}</div>
                            {f.cropType && <span className="text-xs text-muted-foreground">{f.cropType}</span>}
                          </div>
                          {f.location && <div className="text-xs text-muted-foreground">{f.location}</div>}
                          <div className="grid gap-x-4 gap-y-1 text-xs sm:grid-cols-3">
                            <div><span className="text-muted-foreground">Product:</span> {f.product || "—"}</div>
                            <div><span className="text-muted-foreground">Rate:</span> {f.rate || "—"}</div>
                            <div><span className="text-muted-foreground">Acres:</span> {f.acres != null ? fmtAcres(f.acres) : "—"}</div>
                          </div>
                          {f.notes && <div className="text-xs text-muted-foreground">Note: {f.notes}</div>}
                          <div className="flex flex-wrap items-center gap-2 pt-1">
                            {f.latitude != null && f.longitude != null && (
                              <span className="text-xs tabular-nums text-muted-foreground">
                                <MapPin className="inline h-3 w-3 text-primary -mt-0.5" /> {f.latitude.toFixed(5)}, {f.longitude.toFixed(5)}
                              </span>
                            )}
                            {href && (
                              <a
                                href={href}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="hover-elevate inline-flex items-center gap-1 rounded-md border border-border px-2 py-1 text-xs font-medium"
                              >
                                <Navigation className="h-3 w-3" /> View on map
                              </a>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-end gap-2 pt-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => del.mutate(viewing.id)}
                  data-testid="button-delete-submission"
                  className="mr-auto text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4 mr-1" /> Delete
                </Button>
                {viewing.status === "new" && (
                  <>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => dismiss.mutate(viewing.id)}
                      data-testid="button-dismiss-submission"
                    >
                      <X className="h-4 w-4 mr-1" /> Dismiss
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => approve.mutate(viewing.id)}
                      disabled={approve.isPending}
                      data-testid="button-approve-submission"
                    >
                      <CheckCircle2 className="h-4 w-4 mr-1" /> Approve & create
                    </Button>
                  </>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
