import { customers, fields, submissions } from '@shared/schema';
import type {
  Customer,
  InsertCustomer,
  Field,
  InsertField,
  FieldWithCustomer,
  InsertSubmission,
  Submission,
  SubmissionWithFields,
  FieldRequest,
} from '@shared/schema';
import { drizzle } from "drizzle-orm/better-sqlite3";
import Database from "better-sqlite3";
import { eq, desc, sql } from "drizzle-orm";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";

// DATABASE_PATH lets the host mount a persistent disk (e.g. /var/data/data.db on Render).
// Falls back to local data.db for development.
const DB_PATH = process.env.DATABASE_PATH || "data.db";
try { mkdirSync(dirname(DB_PATH), { recursive: true }); } catch {}
const sqlite = new Database(DB_PATH);
sqlite.pragma("journal_mode = WAL");

// Bootstrap schema (idempotent). Drizzle config exists, but we want zero-setup runs.
sqlite.exec(`
  CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT,
    email TEXT,
    address TEXT,
    notes TEXT,
    created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS fields (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    location TEXT,
    latitude REAL,
    longitude REAL,
    acres REAL,
    crop_type TEXT,
    product TEXT,
    rate TEXT,
    notes TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    scheduled_date TEXT,
    sprayed_date TEXT,
    created_at INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS submissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_name TEXT NOT NULL,
    phone TEXT,
    email TEXT,
    address TEXT,
    customer_notes TEXT,
    fields_json TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'new',
    created_at INTEGER NOT NULL
  );
`);

export const db = drizzle(sqlite);

export interface IStorage {
  // Customers
  listCustomers(): Promise<Customer[]>;
  getCustomer(id: number): Promise<Customer | undefined>;
  createCustomer(data: InsertCustomer): Promise<Customer>;
  updateCustomer(id: number, data: Partial<InsertCustomer>): Promise<Customer | undefined>;
  deleteCustomer(id: number): Promise<boolean>;
  // Fields
  listFields(): Promise<FieldWithCustomer[]>;
  listFieldsByCustomer(customerId: number): Promise<Field[]>;
  getField(id: number): Promise<Field | undefined>;
  createField(data: InsertField): Promise<Field>;
  updateField(id: number, data: Partial<InsertField>): Promise<Field | undefined>;
  deleteField(id: number): Promise<boolean>;
  // Submissions
  listSubmissions(): Promise<SubmissionWithFields[]>;
  getSubmission(id: number): Promise<SubmissionWithFields | undefined>;
  createSubmission(data: InsertSubmission): Promise<SubmissionWithFields>;
  updateSubmissionStatus(id: number, status: string): Promise<Submission | undefined>;
  approveSubmission(id: number, fieldDefaults?: Partial<InsertField>): Promise<{ customerId: number; fieldIds: number[] }>;
  deleteSubmission(id: number): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async listCustomers(): Promise<Customer[]> {
    return db.select().from(customers).orderBy(desc(customers.createdAt)).all();
  }

  async getCustomer(id: number): Promise<Customer | undefined> {
    return db.select().from(customers).where(eq(customers.id, id)).get();
  }

  async createCustomer(data: InsertCustomer): Promise<Customer> {
    return db
      .insert(customers)
      .values({ ...data, createdAt: Date.now() })
      .returning()
      .get();
  }

  async updateCustomer(id: number, data: Partial<InsertCustomer>): Promise<Customer | undefined> {
    return db
      .update(customers)
      .set(data)
      .where(eq(customers.id, id))
      .returning()
      .get();
  }

  async deleteCustomer(id: number): Promise<boolean> {
    // Also remove that customer's fields
    db.delete(fields).where(eq(fields.customerId, id)).run();
    const res = db.delete(customers).where(eq(customers.id, id)).run();
    return res.changes > 0;
  }

  async listFields(): Promise<FieldWithCustomer[]> {
    const rows = db
      .select({
        id: fields.id,
        customerId: fields.customerId,
        name: fields.name,
        location: fields.location,
        latitude: fields.latitude,
        longitude: fields.longitude,
        acres: fields.acres,
        cropType: fields.cropType,
        product: fields.product,
        rate: fields.rate,
        notes: fields.notes,
        status: fields.status,
        scheduledDate: fields.scheduledDate,
        sprayedDate: fields.sprayedDate,
        createdAt: fields.createdAt,
        customerName: customers.name,
      })
      .from(fields)
      .leftJoin(customers, eq(fields.customerId, customers.id))
      .orderBy(desc(fields.createdAt))
      .all();
    return rows.map((r) => ({
      ...r,
      customerName: r.customerName ?? "(unknown)",
    })) as FieldWithCustomer[];
  }

  async listFieldsByCustomer(customerId: number): Promise<Field[]> {
    return db
      .select()
      .from(fields)
      .where(eq(fields.customerId, customerId))
      .orderBy(desc(fields.createdAt))
      .all();
  }

  async getField(id: number): Promise<Field | undefined> {
    return db.select().from(fields).where(eq(fields.id, id)).get();
  }

  async createField(data: InsertField): Promise<Field> {
    return db
      .insert(fields)
      .values({ ...data, createdAt: Date.now() })
      .returning()
      .get();
  }

  async updateField(id: number, data: Partial<InsertField>): Promise<Field | undefined> {
    return db
      .update(fields)
      .set(data)
      .where(eq(fields.id, id))
      .returning()
      .get();
  }

  async deleteField(id: number): Promise<boolean> {
    const res = db.delete(fields).where(eq(fields.id, id)).run();
    return res.changes > 0;
  }

  // --- Submissions ---
  private hydrate(s: Submission): SubmissionWithFields {
    let parsed: FieldRequest[] = [];
    try { parsed = JSON.parse(s.fieldsJson) as FieldRequest[]; } catch { parsed = []; }
    return { ...s, fields: parsed };
  }

  async listSubmissions(): Promise<SubmissionWithFields[]> {
    const rows = db.select().from(submissions).orderBy(desc(submissions.createdAt)).all();
    return rows.map((r) => this.hydrate(r));
  }

  async getSubmission(id: number): Promise<SubmissionWithFields | undefined> {
    const row = db.select().from(submissions).where(eq(submissions.id, id)).get();
    return row ? this.hydrate(row) : undefined;
  }

  async createSubmission(data: InsertSubmission): Promise<SubmissionWithFields> {
    const row = db
      .insert(submissions)
      .values({
        customerName: data.customerName,
        phone: data.phone ?? null,
        email: data.email || null,
        address: data.address ?? null,
        customerNotes: data.customerNotes ?? null,
        fieldsJson: JSON.stringify(data.fields),
        status: "new",
        createdAt: Date.now(),
      })
      .returning()
      .get();
    return this.hydrate(row);
  }

  async updateSubmissionStatus(id: number, status: string): Promise<Submission | undefined> {
    return db.update(submissions).set({ status }).where(eq(submissions.id, id)).returning().get();
  }

  async approveSubmission(id: number): Promise<{ customerId: number; fieldIds: number[] }> {
    const sub = await this.getSubmission(id);
    if (!sub) throw new Error("Submission not found");

    // Create customer
    const customer = await this.createCustomer({
      name: sub.customerName,
      phone: sub.phone,
      email: sub.email,
      address: sub.address,
      notes: sub.customerNotes,
    });

    // Create fields
    const fieldIds: number[] = [];
    for (const f of sub.fields) {
      const created = await this.createField({
        customerId: customer.id,
        name: f.name,
        location: f.location ?? null,
        latitude: f.latitude ?? null,
        longitude: f.longitude ?? null,
        acres: f.acres ?? null,
        cropType: f.cropType ?? null,
        product: f.product ?? null,
        rate: f.rate ?? null,
        notes: f.notes ?? null,
        status: "pending",
        scheduledDate: null,
        sprayedDate: null,
      } as InsertField);
      fieldIds.push(created.id);
    }

    db.update(submissions).set({ status: "approved" }).where(eq(submissions.id, id)).run();
    return { customerId: customer.id, fieldIds };
  }

  async deleteSubmission(id: number): Promise<boolean> {
    const res = db.delete(submissions).where(eq(submissions.id, id)).run();
    return res.changes > 0;
  }
}

export const storage = new DatabaseStorage();
