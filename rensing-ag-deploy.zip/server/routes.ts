import type { Express, Request, Response } from "express";
import { createServer } from 'node:http';
import type { Server } from 'node:http';
import { storage } from "./storage";
import { insertCustomerSchema, insertFieldSchema, insertSubmissionSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // --- Customers ---
  app.get("/api/customers", async (_req, res) => {
    res.json(await storage.listCustomers());
  });

  app.get("/api/customers/:id", async (req, res) => {
    const id = Number(req.params.id);
    const customer = await storage.getCustomer(id);
    if (!customer) return res.status(404).json({ error: "Customer not found" });
    const fields = await storage.listFieldsByCustomer(id);
    res.json({ ...customer, fields });
  });

  app.post("/api/customers", async (req, res) => {
    try {
      const data = insertCustomerSchema.parse(req.body);
      res.json(await storage.createCustomer(data));
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ error: err.errors });
      throw err;
    }
  });

  app.patch("/api/customers/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      const data = insertCustomerSchema.partial().parse(req.body);
      const updated = await storage.updateCustomer(id, data);
      if (!updated) return res.status(404).json({ error: "Customer not found" });
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ error: err.errors });
      throw err;
    }
  });

  app.delete("/api/customers/:id", async (req, res) => {
    const ok = await storage.deleteCustomer(Number(req.params.id));
    if (!ok) return res.status(404).json({ error: "Customer not found" });
    res.json({ ok: true });
  });

  // --- Fields ---
  app.get("/api/fields", async (_req, res) => {
    res.json(await storage.listFields());
  });

  app.get("/api/fields/:id", async (req, res) => {
    const field = await storage.getField(Number(req.params.id));
    if (!field) return res.status(404).json({ error: "Field not found" });
    res.json(field);
  });

  app.post("/api/fields", async (req, res) => {
    try {
      const data = insertFieldSchema.parse(req.body);
      res.json(await storage.createField(data));
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ error: err.errors });
      throw err;
    }
  });

  app.patch("/api/fields/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      const data = insertFieldSchema.partial().parse(req.body);
      const updated = await storage.updateField(id, data);
      if (!updated) return res.status(404).json({ error: "Field not found" });
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ error: err.errors });
      throw err;
    }
  });

  app.delete("/api/fields/:id", async (req, res) => {
    const ok = await storage.deleteField(Number(req.params.id));
    if (!ok) return res.status(404).json({ error: "Field not found" });
    res.json({ ok: true });
  });

  // --- Submissions (customer-facing intake) ---
  app.get("/api/submissions", async (_req, res) => {
    res.json(await storage.listSubmissions());
  });

  app.get("/api/submissions/:id", async (req, res) => {
    const sub = await storage.getSubmission(Number(req.params.id));
    if (!sub) return res.status(404).json({ error: "Not found" });
    res.json(sub);
  });

  // PUBLIC — anyone can submit
  app.post("/api/submissions", async (req, res) => {
    try {
      const data = insertSubmissionSchema.parse(req.body);
      const created = await storage.createSubmission(data);
      res.json({ ok: true, id: created.id });
    } catch (err) {
      if (err instanceof z.ZodError) return res.status(400).json({ error: err.errors });
      throw err;
    }
  });

  app.post("/api/submissions/:id/approve", async (req, res) => {
    try {
      const result = await storage.approveSubmission(Number(req.params.id));
      res.json(result);
    } catch (err: any) {
      res.status(400).json({ error: err.message || "Could not approve" });
    }
  });

  app.post("/api/submissions/:id/dismiss", async (req, res) => {
    const updated = await storage.updateSubmissionStatus(Number(req.params.id), "dismissed");
    if (!updated) return res.status(404).json({ error: "Not found" });
    res.json(updated);
  });

  app.delete("/api/submissions/:id", async (req, res) => {
    const ok = await storage.deleteSubmission(Number(req.params.id));
    if (!ok) return res.status(404).json({ error: "Not found" });
    res.json({ ok: true });
  });

  return httpServer;
}
